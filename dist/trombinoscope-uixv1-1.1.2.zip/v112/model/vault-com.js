/* exported coffre */
/* =====================================================================
   VAULT-COM \u2014 acc\u00e8s au coffre en UIX v1 (API COM synchrone, ES5)

   Couche model. Isole toutes les particularit\u00e9s COM (collections base 1,
   constructeurs MFiles.*, recherches par conditions) et rend des objets
   JavaScript simples aux r\u00e8gles (regles.js).

   Lecture seule : ce module n'\u00e9crit rien dans le coffre.

   CONFIDENTIALIT\u00c9 : une fiche n'est lue que propri\u00e9t\u00e9 par propri\u00e9t\u00e9, par
   SearchForProperty sur les identifiants de la liste blanche
   (PARAMETRAGE.proprietes). Les PropertyValues ne sont jamais parcourues :
   une propri\u00e9t\u00e9 qui n'est pas nomm\u00e9e ici n'est jamais lue, donc ne peut
   pas fuiter vers la page.
   ===================================================================== */

var coffre = (function () {
    "use strict";

    /**
     * Convertit une collection COM (base 1, .Count/.Item) en tableau.
     *
     * @param {object} collection collection COM
     * @returns {Array} \u00e9l\u00e9ments, dans l'ordre
     */
    function enTableau(collection) {
        var sortie = [];
        var i;

        if (!collection) {
            return sortie;
        }
        for (i = 1; i <= collection.Count; i += 1) {
            sortie.push(collection.Item(i));
        }
        return sortie;
    }

    /**
     * Condition sur une valeur de statut (type d'objet, supprim\u00e9).
     *
     * @param {number} statut MF.STATUS_*
     * @param {number} datatype MF.DT_*
     * @param {*} valeur valeur attendue
     * @returns {object} MFiles.SearchCondition
     */
    function conditionStatut(statut, datatype, valeur) {
        var c = new MFiles.SearchCondition();

        c.ConditionType = MF.EGAL;
        c.Expression.SetStatusValueExpression(statut, null);
        c.TypedValue.SetValue(datatype, valeur);
        return c;
    }

    /**
     * Condition \u00ab propri\u00e9t\u00e9 lookup \u00e9gale \u00e0 un \u00e9l\u00e9ment \u00bb.
     *
     * @param {number} propriete identifiant de la propri\u00e9t\u00e9
     * @param {number} valeur identifiant de l'\u00e9l\u00e9ment
     * @returns {object} MFiles.SearchCondition
     */
    function conditionLookup(propriete, valeur) {
        var c = new MFiles.SearchCondition();

        c.ConditionType = MF.EGAL;
        c.Expression.SetPropertyValueExpression(propriete, MF.PARENT_CHILD_NONE, null);
        c.TypedValue.SetValue(MF.DT_LOOKUP, valeur);
        return c;
    }

    /**
     * Lance une recherche ; un r\u00e9sultat plafonn\u00e9 est une erreur franche :
     * un annuaire amput\u00e9 sans le dire serait pire qu'un \u00e9chec.
     *
     * @param {object} vault coffre COM
     * @param {Array} liste conditions
     * @param {string} quoi ce qui est cherch\u00e9, pour le message
     * @returns {Array} ObjectVersion trouv\u00e9es
     */
    function chercher(vault, liste, quoi) {
        var conditions = new MFiles.SearchConditions();
        var res;

        liste.forEach(function (c) {
            conditions.Add(-1, c);
        });
        // D\u00e9lai de 30 s, comme le code v1 \u00e9prouv\u00e9 (skill m-files-ui-ext-v1)
        res = vault.ObjectSearchOperations.SearchForObjectsByConditionsEx(
            conditions, MF.SEARCH_FLAG_NONE, false, PARAMETRAGE.limiteRecherche, PARAMETRAGE.delaiRecherche);

        if (res.MoreResults) {
            throw new Error("M-Files compte plus de " + PARAMETRAGE.limiteRecherche + " " + quoi +
                " : annuaire incomplet, lecture interrompue.");
        }
        return enTableau(res);
    }

    /**
     * Collaborateurs d'une \u00e9tape de workflow (non supprim\u00e9s).
     *
     * @param {object} vault coffre COM
     * @param {number} idEtape identifiant de l'\u00e9tape
     * @returns {Array} ObjVer trouv\u00e9s
     */
    function chercherCollaborateurs(vault, idEtape) {
        return chercher(vault, [
            conditionStatut(MF.STATUS_OBJECT_TYPE_ID, MF.DT_LOOKUP, PARAMETRAGE.typeCollaborateur),
            conditionLookup(PARAMETRAGE.proprietes.etape, idEtape),
            conditionStatut(MF.STATUS_DELETED, MF.DT_BOOLEAN, false)
        ], "collaborateurs \u00e0 cette \u00e9tape").map(function (v) {
            return v.ObjVer;
        });
    }

    /**
     * Tous les objets Cercle/r\u00f4le (non supprim\u00e9s), avec leur titre.
     *
     * @param {object} vault coffre COM
     * @returns {Array} [{ objVer, id, nom }]
     */
    function chercherCercles(vault) {
        return chercher(vault, [
            conditionStatut(MF.STATUS_OBJECT_TYPE_ID, MF.DT_LOOKUP, PARAMETRAGE.typeCercle),
            conditionStatut(MF.STATUS_DELETED, MF.DT_BOOLEAN, false)
        ], "cercles et r\u00f4les").map(function (v) {
            return { objVer: v.ObjVer, id: v.ObjVer.ID, nom: v.Title };
        });
    }

    /**
     * TypedValue d'une propri\u00e9t\u00e9 nomm\u00e9e, ou null si absente ou vide.
     *
     * @param {object} pvs PropertyValues de l'objet
     * @param {number} id identifiant de la propri\u00e9t\u00e9 (liste blanche)
     * @returns {object|null} TypedValue
     */
    function valeurDe(pvs, id) {
        var pv;
        var tv;

        if (pvs.IndexOf(id) === -1) {
            return null;
        }
        pv = pvs.SearchForProperty(id);
        tv = pv.TypedValue || pv.Value;
        return tv && !tv.IsNULL() ? tv : null;
    }

    /**
     * Texte d'une propri\u00e9t\u00e9.
     *
     * @param {object} pvs PropertyValues
     * @param {number} id propri\u00e9t\u00e9
     * @returns {string|null} texte affich\u00e9, null si vide
     */
    function texte(pvs, id) {
        var tv = valeurDe(pvs, id);
        return tv && tv.DisplayValue ? String(tv.DisplayValue) : null;
    }

    /**
     * Lookup simple d'une propri\u00e9t\u00e9.
     *
     * @param {object} pvs PropertyValues
     * @param {number} id propri\u00e9t\u00e9
     * @returns {object|null} { id, nom }
     */
    function lookup(pvs, id) {
        var tv = valeurDe(pvs, id);
        var l;

        if (!tv) {
            return null;
        }
        l = tv.GetValueAsLookup();
        return { id: l.Item, nom: l.DisplayValue };
    }

    /**
     * Lookups d'une propri\u00e9t\u00e9 \u00e0 s\u00e9lection multiple, sans les \u00e9l\u00e9ments
     * supprim\u00e9s.
     *
     * @param {object} pvs PropertyValues
     * @param {number} id propri\u00e9t\u00e9
     * @returns {Array} [{ id, nom }]
     */
    function lookups(pvs, id) {
        var tv = valeurDe(pvs, id);

        if (!tv) {
            return [];
        }
        return enTableau(tv.GetValueAsLookups()).filter(function (l) {
            return !l.Deleted;
        }).map(function (l) {
            return { id: l.Item, nom: l.DisplayValue };
        });
    }

    /**
     * Collection ObjVers d'un lot.
     *
     * @param {Array} objVers ObjVer
     * @returns {object} MFiles.ObjVers
     */
    function collectionObjVers(objVers) {
        var c = new MFiles.ObjVers();

        objVers.forEach(function (ov) {
            c.Add(-1, ov);
        });
        return c;
    }

    /**
     * Lit un lot de fiches Collaborateur en un aller-retour et n'en garde
     * que la liste blanche.
     *
     * @param {object} vault coffre COM
     * @param {Array} objVers ObjVer du lot
     * @returns {Array} fiches { id, prenom, nom, initiales, titre,
     *     titreManuel, etape, fonctionPrincipale, fonctions, succursale,
     *     cercle, cerclesAuto, responsableId, email }
     */
    function lireFiches(vault, objVers) {
        var p = PARAMETRAGE.proprietes;
        var lots = enTableau(vault.ObjectPropertyOperations.GetPropertiesOfMultipleObjects(collectionObjVers(objVers)));

        return lots.map(function (pvs, i) {
            var fonction = lookup(pvs, p.fonctionPrincipale);
            var succursale = lookup(pvs, p.succursale);
            var responsable = lookup(pvs, p.responsable);

            return {
                id: objVers[i].ID,
                prenom: texte(pvs, p.prenom),
                nom: texte(pvs, p.nom),
                initiales: texte(pvs, p.initiales),
                titre: texte(pvs, p.titre),
                titreManuel: texte(pvs, p.titreManuel),
                etape: lookup(pvs, p.etape),
                fonctionPrincipale: fonction ? fonction.nom : null,
                fonctions: lookups(pvs, p.fonctions).map(function (l) { return l.nom; }),
                succursale: succursale ? succursale.nom : null,
                cercle: lookup(pvs, p.cercle),
                cerclesAuto: lookups(pvs, p.cerclesAuto),
                responsableId: responsable ? responsable.id : null,
                email: texte(pvs, p.email)
            };
        });
    }

    /**
     * Lit un lot de cercles et r\u00f4les : ce que chacun contient.
     *
     * @param {object} vault coffre COM
     * @param {Array} cercles [{ objVer, id, nom }] (voir chercherCercles)
     * @returns {Array} [{ id, nom, enfants }]
     */
    function lireCercles(vault, cercles) {
        var lots = enTableau(vault.ObjectPropertyOperations.GetPropertiesOfMultipleObjects(
            collectionObjVers(cercles.map(function (c) { return c.objVer; }))));

        return lots.map(function (pvs, i) {
            return {
                id: cercles[i].id,
                nom: cercles[i].nom,
                enfants: lookups(pvs, PARAMETRAGE.proprietesCercle.membresCercles).map(function (l) { return l.id; })
            };
        });
    }

    /**
     * Taille d'un fichier en octets. LogicalSize est un entier 64 bits que
     * JScript ne sait pas toujours lire : la variante 32 bits d'abord.
     *
     * @param {object} f ObjectFile
     * @returns {number} taille, ou -1 si illisible
     */
    function tailleDe(f) {
        try {
            return Number(f.LogicalSize_32bit);
        } catch (e) {
            try {
                return Number(f.LogicalSize);
            } catch (e2) {
                return -1;
            }
        }
    }

    /**
     * Documents de portrait d'un collaborateur, le plus r\u00e9cent d'abord
     * (un ID de document plus grand est un document cr\u00e9\u00e9 plus tard), avec
     * leurs fichiers. Rien d'autre n'est lu du document.
     *
     * @param {object} vault coffre COM
     * @param {number} personneId ID du collaborateur
     * @returns {Array} [{ id, objVer, fichiers: [{ id, version, extension, taille }] }]
     */
    function chercherPortraits(vault, personneId) {
        var docs = chercher(vault, [
            conditionStatut(MF.STATUS_OBJECT_TYPE_ID, MF.DT_LOOKUP, PARAMETRAGE.typeDocument),
            conditionLookup(PARAMETRAGE.proprietesPhoto.classe, PARAMETRAGE.classePhoto),
            conditionLookup(PARAMETRAGE.proprietesPhoto.collaborateur, personneId),
            conditionStatut(MF.STATUS_DELETED, MF.DT_BOOLEAN, false)
        ], "documents de portrait");

        return docs.map(function (v) {
            return {
                id: v.ObjVer.ID,
                objVer: v.ObjVer,
                fichiers: enTableau(vault.ObjectFileOperations.GetFiles(v.ObjVer)).map(function (f) {
                    return { id: f.ID, version: f.Version, extension: String(f.Extension || "").toLowerCase(),
                        taille: tailleDe(f) };
                })
            };
        }).sort(function (a, b) {
            return b.id - a.id;
        });
    }

    /**
     * Contenu d'un fichier en URI data: base64, en m\u00e9moire (aucun fichier
     * sur disque). DownloadFileAsDataURI(ObjVer, File, FileVersion), dont la
     * r\u00e9f\u00e9rence de l'API COM dit l'int\u00e9r\u00eat pour l'UI Extensibility
     * Framework (petites images d'un tableau de bord).
     *
     * @param {object} vault coffre COM
     * @param {object} objVer ObjVer du document
     * @param {number} fichierId ID du fichier
     * @param {number} fichierVersion version du fichier
     * @returns {string} URI data:
     */
    function lireDataUri(vault, objVer, fichierId, fichierVersion) {
        return String(vault.ObjectFileOperations.DownloadFileAsDataURI(objVer, fichierId, fichierVersion));
    }

    /**
     * Affiche la fiche native d'un objet absent du listing. Collection
     * ObjOrFileVers (r\u00e9f\u00e9rence v1) : ObjectVersions \u00e9choue toujours.
     *
     * @param {object} cadre ShellFrame
     * @param {object} objVer ObjVer de l'objet
     * @returns {boolean} vrai si accept\u00e9e
     */
    function selectionVirtuelle(cadre, objVer) {
        var selection;
        var element;
        var listing = null;

        try {
            selection = new MFiles.ObjOrFileVers();
            element = new MFiles.ObjOrFileVer();
            try {
                listing = cadre.ActiveListing;
            } catch (e) {
                listing = null;
            }
            element.ObjVer = objVer;
            selection.Add(-1, element);
            (listing || cadre.Listing).SetVirtualSelection(selection);
            return true;
        } catch (e) {
            console.log(PREFIXE_JOURNAL + " s\u00e9lection virtuelle refus\u00e9e : " + (e.message || e.description || e));
            return false;
        }
    }

    return {
        enTableau: enTableau,
        chercherCollaborateurs: chercherCollaborateurs,
        chercherCercles: chercherCercles,
        lireFiches: lireFiches,
        lireCercles: lireCercles,
        chercherPortraits: chercherPortraits,
        lireDataUri: lireDataUri,
        selectionVirtuelle: selectionVirtuelle
    };
}());
